package com.example.dimanor3.itunestopgrossingappfinder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Dimanor3 on 3/12/2018.
 */

public class AppAdapter extends ArrayAdapter<App> {
	public AppAdapter (Context context, int resource, List<App> objects) {
		super (context, resource, objects);
	}

	@Override
	public View getView (int position, View convertView, ViewGroup parent) {
		App app = getItem (position);
		ViewHolder viewHolder;

		if (convertView == null) { //if no view to re-use then inflate a new one
			convertView = LayoutInflater.from (getContext ()).inflate (R.layout.app_item, parent, false);
			viewHolder = new ViewHolder ();
			viewHolder.imageView = (ImageView) convertView.findViewById (R.id.imageViewApp);
			viewHolder.appName = (TextView) convertView.findViewById (R.id.textViewAppName);
			viewHolder.artistName = (TextView) convertView.findViewById (R.id.textViewArtistName);
			viewHolder.genres = (TextView) convertView.findViewById (R.id.textViewGenre);
			viewHolder.releaseDate = (TextView) convertView.findViewById (R.id.textViewReleaseDate);
			convertView.setTag (viewHolder);
		} else {
			viewHolder = (ViewHolder) convertView.getTag ();
		}

		String genrez = "";

		for (Genre genre: app.genres) {
			genrez += genre.genreName + ", ";
		}

		//set the data from the email object
		viewHolder.appName.setText (app.appName);
		viewHolder.artistName.setText (app.devName);
		viewHolder.genres.setText (genrez);
		viewHolder.releaseDate.setText (app.releaseDate);

		Picasso.get ().load (app.imgUrl).into (viewHolder.imageView);

		return convertView;
	}

	//View Holder to cache the views
	private static class ViewHolder {
		ImageView imageView;
		TextView appName;
		TextView artistName;
		TextView genres;
		TextView releaseDate;
	}
}
