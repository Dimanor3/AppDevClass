package com.example.dimanor3.itunestopgrossingappfinder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Created by Dimanor3 on 3/12/2018.
 */

public class App implements Serializable {
	String appName, devName, releaseDate, imgUrl, copyright;
	ArrayList<Genre> genres;

	public App () {
	}

	@Override
	public String toString () {
		String result = "App{" +
				"appName='" + appName + '\'' +
				", devName='" + devName + '\'' +
				", releaseDate='" + releaseDate + '\'' +
				", imgUrl='" + imgUrl + '\'' +
				", genres=";

		for (Genre genre: genres) {
			result += genre.toString () + ";";
		}

		result += '}';

		return result;
	}
}
