/*
* Assignment# 4
* File Name: RSSParser.java
* Full Name: Ryan Haines, Bijan Razavi, Sonia Alcantara Tuscano, Kushal Tiwari
* */

package com.example.dimanor3.itunestopgrossingappfinder;

import android.util.Log;
import android.util.Xml;

import org.apache.commons.io.IOUtils;
import org.apache.commons.io.input.XmlStreamReader;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by ryanhaines on 2/21/18.
 */

public class RSSParser {
	public static class RSSPullParser {
		static public ArrayList<App> parseApps (InputStream inputStream) throws XmlPullParserException, IOException {
			ArrayList<App> apps = new ArrayList<> ();
			App app = null;
			ArrayList<Genre> genres = new ArrayList<> ();
			Genre genre = null;
			XmlPullParserFactory factory = XmlPullParserFactory.newInstance ();
			XmlPullParser parser = factory.newPullParser ();
			parser.setInput (inputStream, "UTF-8");

			int event = parser.getEventType ();

			Log.d ("demo", Integer.toString (XmlPullParser.START_DOCUMENT));

			while (event != XmlPullParser.END_DOCUMENT) {
				Log.d ("demo", Integer.toString (event));
				switch (event) {
					case XmlPullParser.START_DOCUMENT:
						Log.d ("demo", Integer.toString (event));

						Log.d ("demo", "Document Started");
						break;
					case XmlPullParser.START_TAG:
						Log.d ("demo", "Got in!");
						if (parser.getName ().equals ("results")) {
							app = new App ();
						} else if (app != null && parser.getName ().equals ("artistName")) {
							app.devName = parser.nextText ().trim ();
						} else if (app != null && parser.getName ().equals ("name")) {
							Log.d ("demo", "I've worked so far!");
							app.appName = parser.nextText ().trim ();
							//app.description = app.description.split("<")[0];
						} else if (app != null && parser.getName ().equals ("copyright")) {
							app.copyright = parser.nextText ().trim ();
						} else if (app != null && parser.getName ().equals ("artworkUrl100")) {
							app.imgUrl = parser.getAttributeValue (null, "url");
						} else if (app != null && parser.getName ().equals ("genres")) {
							genre = new Genre ();
							genres = new ArrayList<> ();
						} else if (app != null && parser.getName ().equals ("genreId")) {
							genre.genreID = Integer.parseInt (parser.getAttributeValue (null, "url"));
						} else if (app != null && parser.getName ().equals ("name")) {
							genre.genreName = parser.getAttributeValue (null, "url");
						}
						break;
					case XmlPullParser.END_TAG:
						if (parser.getName ().equals ("genres")) {
							genres.add (genre);
							app.genres = genres;
							genre = null;
							genres = null;
						} else if (parser.getName ().equals ("results")) {
							apps.add (app);
							app = null;
						}
						break;
					default:
						break;
				}

				event = parser.next ();
			}

			return apps;
		}
	}
}
