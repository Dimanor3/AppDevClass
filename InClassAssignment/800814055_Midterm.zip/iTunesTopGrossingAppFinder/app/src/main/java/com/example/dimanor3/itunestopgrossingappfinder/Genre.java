package com.example.dimanor3.itunestopgrossingappfinder;

/**
 * Created by Dimanor3 on 3/12/2018.
 */

public class Genre {
	int genreID;
	String genreName;

	public Genre () {
	}

	public Genre (int genreID, String genreName) {
		this.genreID = genreID;
		this.genreName = genreName;
	}

	@Override
	public String toString () {
		return "Genre{" +
				"genreID=" + genreID +
				", genreName='" + genreName + '\'' +
				'}';
	}
}
