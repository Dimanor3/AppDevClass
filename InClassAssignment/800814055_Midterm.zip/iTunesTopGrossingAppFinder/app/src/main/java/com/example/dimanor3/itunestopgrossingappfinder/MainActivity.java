package com.example.dimanor3.itunestopgrossingappfinder;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {

	ArrayList<App> apps = new ArrayList<> ();
	ArrayList<Genre> genres = new ArrayList<> ();

	TextView all;

	static final String APPS_KEY = "APPS";

	@Override
	protected void onCreate (Bundle savedInstanceState) {
		super.onCreate (savedInstanceState);
		setContentView (R.layout.activity_main);

		setTitle ("Apps");

		all = (TextView) findViewById (R.id.all);

		if (isConnected ()) {
			Toast.makeText (getApplicationContext (), "Connected to Network", Toast.LENGTH_LONG).show ();

			new GetDataAsync ().execute ("https://rss.itunes.apple.com/api/v1/us/ios-apps/top-grossing/all/50/explicit.json");
		} else {
			Toast.makeText (getApplicationContext (), "Not Connected to Network", Toast.LENGTH_LONG).show ();
		}

		genres.add (new Genre (0, "All"));

		for (App app: apps) {
			for (Genre genre: app.genres) {
				if (!genres.contains (genre)) {
					genres.add (genre);
				}
			}
		}

		ListView listView = (ListView) findViewById (R.id.listView);
		ArrayAdapter adapter = new ArrayAdapter (this, R.layout.app_item, apps);
		listView.setAdapter (adapter);

		listView.setOnItemClickListener (new AdapterView.OnItemClickListener () {
			@Override
			public void onItemClick (AdapterView<?> parent, View view, int position, long id) {
				Intent intent = new Intent (MainActivity.this, DetailActivity.class);

				intent.putExtra (APPS_KEY, apps.get (position));

				startActivity (intent);
			}
		});
	}

	public void filter (View v) {
		AlertDialog.Builder builder = new AlertDialog.Builder (this);

		ArrayList<CharSequence> items = new ArrayList<> ();

		for (Genre genre: genres) {
			items.add (genre.genreName);
		}

		CharSequence[] itemsChar = Arrays.copyOf (items.toArray (), items.size (), CharSequence[].class);

		builder.setTitle ("Choose Genre")
				.setSingleChoiceItems (itemsChar, 0, new DialogInterface.OnClickListener () {
					@Override
					public void onClick (DialogInterface dialog, int which) {
						String choosenGenre = genres.get (which).genreName;

						all.setText (choosenGenre);
					}
				})
				.setCancelable (false);
	}

	private boolean isConnected () {
		ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService (Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo ();

		if (networkInfo == null || !networkInfo.isConnected () ||
				(networkInfo.getType () != ConnectivityManager.TYPE_WIFI
						&& networkInfo.getType () != ConnectivityManager.TYPE_MOBILE)) {
			return false;
		}
		return true;
	}

	private class GetDataAsync extends AsyncTask<String, Void, ArrayList<App>> {
		ProgressDialog progressDialog = new ProgressDialog (MainActivity.this);

		@Override
		protected void onPreExecute () {
			progressDialog.setMessage ("Loading Apps ...");
			progressDialog.show ();
		}

		@Override
		protected ArrayList<App> doInBackground (String... params) {
			HttpURLConnection connection = null;
			ArrayList<App> result = new ArrayList<> ();

			try {
				URL url = new URL (params[0]);
				connection = (HttpURLConnection) url.openConnection ();
				connection.connect ();
				if (connection.getResponseCode () == HttpURLConnection.HTTP_OK) {
					Log.d ("connection", "Connection Made");
					result = RSSParser.RSSPullParser.parseApps (connection.getInputStream ());
				} else {
					Log.d ("connection", "Connection Failed");
				}
			} catch (XmlPullParserException | IOException e) {
				e.printStackTrace ();
			} finally {
				if (connection != null) {
					connection.disconnect ();
				}
			}

			return result;
		}

		@Override
		protected void onPostExecute (ArrayList<App> result) {
			if (result.size () > 0) {
				Log.d ("result", result.toString ());

				progressDialog.dismiss ();

				apps.addAll (result);
			} else {
				progressDialog.dismiss ();

				Log.d ("result", "empty result");
			}
		}
	}
}
