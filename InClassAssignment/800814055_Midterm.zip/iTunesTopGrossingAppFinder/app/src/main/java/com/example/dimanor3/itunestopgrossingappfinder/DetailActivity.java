package com.example.dimanor3.itunestopgrossingappfinder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DetailActivity extends AppCompatActivity {

	TextView appName, releaseDate, appGenre, appDeveloper, appCopyright;
	ImageView imageView;

	App app;

	//Articles articles;

	@Override
	protected void onCreate (Bundle savedInstanceState) {
		super.onCreate (savedInstanceState);
		setContentView (R.layout.activity_detail);

		setTitle ("Detail Activity");

		appName = (TextView) findViewById (R.id.appName);
		releaseDate = (TextView) findViewById (R.id.releaseDate);
		appGenre = (TextView) findViewById (R.id.appGenre);
		appDeveloper = (TextView) findViewById (R.id.appDeveloper);
		appCopyright = (TextView) findViewById (R.id.appCopyright);

		imageView = (ImageView) findViewById (R.id.imageView);

		if (getIntent () != null && getIntent ().getExtras () != null) {
			app = (App) getIntent ().getExtras ().getSerializable (MainActivity.APPS_KEY);
			//articles = (Articles) getIntent ().getExtras ().getSerializable (Category.);
		}

		appName.setText (app.appName);
		releaseDate.setText (app.releaseDate);
		appDeveloper.setText (app.devName);
		appCopyright.setText (app.copyright);

		Picasso.get ().load (app.imgUrl).into (imageView);

		String genrez = "";

		for (Genre genre: app.genres) {
			genrez += genre.genreName + ", ";
		}

		appGenre.setText (genrez);
	}
}
